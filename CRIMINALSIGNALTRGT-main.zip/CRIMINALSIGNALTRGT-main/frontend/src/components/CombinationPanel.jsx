import { useState, useEffect, useMemo } from 'react';

const MAX_SIGNALS = 50;

export default function CombinationPanel({ data, activeTimeframes }) {
  const [signals, setSignals] = useState({ up: [], down: [] });
  const [shownSymbols, setShownSymbols] = useState(new Set());
  const [activeComboTimeframes, setActiveComboTimeframes] = useState(() => {
    const saved = localStorage.getItem('activeComboTimeframes');
    return saved ? JSON.parse(saved) : {
      M1: true, M3: true, M5: true, M15: true,
      H1: true, H4: true, H6: true, D1: true,
      '1H': true, '1AY': true
    };
  });

  const TIMEFRAMES = ['M1', 'M3', 'M5', 'M15', 'H1', 'H4', 'H6', 'D1', '1H', '1AY'];

  useEffect(() => {
    localStorage.setItem('activeComboTimeframes', JSON.stringify(activeComboTimeframes));
  }, [activeComboTimeframes]);

  const toggleComboTimeframe = (tf) => {
    setActiveComboTimeframes(prev => ({ ...prev, [tf]: !prev[tf] }));
  };

  const combinationSignals = useMemo(() => {
    const activeTFs = Object.keys(activeComboTimeframes).filter(tf => activeComboTimeframes[tf]);
    
    if (activeTFs.length === 0) {
      return { up: [], down: [] };
    }

    const upSignals = [];
    const downSignals = [];

    data.forEach(coin => {
      const allUp = activeTFs.every(tf => coin.signals[tf] === 'up');
      const allDown = activeTFs.every(tf => coin.signals[tf] === 'down');

      if (allUp && !shownSymbols.has(coin.symbol)) {
        upSignals.push({
          symbol: coin.symbol,
          price: coin.price,
          change: coin.change_24h,
          timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
        });
      } else if (allDown && !shownSymbols.has(coin.symbol)) {
        downSignals.push({
          symbol: coin.symbol,
          price: coin.price,
          change: coin.change_24h,
          timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
        });
      }
    });

    return { up: upSignals, down: downSignals };
  }, [data, activeComboTimeframes, shownSymbols]);

  useEffect(() => {
    if (combinationSignals.up.length > 0 || combinationSignals.down.length > 0) {
      setSignals(prev => {
        const newUp = [...combinationSignals.up, ...prev.up].slice(0, MAX_SIGNALS);
        const newDown = [...combinationSignals.down, ...prev.down].slice(0, MAX_SIGNALS);
        
        const newShownSymbols = new Set([
          ...newUp.map(s => s.symbol),
          ...newDown.map(s => s.symbol)
        ]);
        setShownSymbols(newShownSymbols);

        return { up: newUp, down: newDown };
      });
    }
  }, [combinationSignals]);

  const formatPrice = (price) => {
    if (price >= 1000) return `$${price.toFixed(2)}`;
    if (price >= 1) return `$${price.toFixed(4)}`;
    return `$${price.toFixed(6)}`;
  };

  return (
    <div className="space-y-4" data-testid="combination-panel">
      {/* Timeframe Buttons - Compact and aligned with main panel headers */}
      <div className="flex gap-1.5 flex-wrap" style={{ background: '#16224A', padding: '12px', borderRadius: '8px', border: '1px solid #1a2147' }}>
        {TIMEFRAMES.map(tf => (
          <button
            key={tf}
            onClick={() => toggleComboTimeframe(tf)}
            className="px-2 py-1 rounded text-xs font-bold text-white transition-all"
            style={{ 
              background: activeComboTimeframes[tf] ? '#084808' : '#333',
              opacity: activeComboTimeframes[tf] ? 1 : 0.5,
              cursor: 'pointer',
              minWidth: '35px'
            }}
            data-testid={`combo-tf-${tf}`}
          >
            {tf}
          </button>
        ))}
      </div>

      {/* Two Column Layout */}
      <div className="grid grid-cols-2 gap-4">
        {/* Yükseliş Column (Left) */}
        <div data-testid="risers-panel">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-6 h-6 bg-[#084808] rounded" />
            <h2 className="text-lg font-bold" style={{ color: '#084808' }}>
              Yükseliş ({signals.up.length})
            </h2>
          </div>

          {signals.up.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-sm" data-testid="no-risers">
              Sinyal yok
            </div>
          ) : (
            <div className="space-y-2 max-h-[calc(100vh-250px)] overflow-y-auto pr-2">
              {signals.up.map((signal, index) => (
                <div
                  key={`${signal.symbol}-${index}`}
                  className="p-2 rounded hover:bg-[#0a5a0a] transition-colors"
                  style={{ background: '#084808', border: '2px solid #0a5a0a' }}
                  data-testid={`riser-${signal.symbol}`}
                >
                  <div className="mb-1">
                    <span className="font-bold text-base" style={{ color: '#FFD700' }}>
                      {signal.symbol}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white text-xs">{formatPrice(signal.price)}</span>
                    <span className="text-white font-bold text-sm">
                      +{signal.change.toFixed(2)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Düşüş Column (Right) */}
        <div data-testid="fallers-panel">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-6 h-6 bg-[#640b0b] rounded" />
            <h2 className="text-lg font-bold" style={{ color: '#640b0b' }}>
              Düşüş ({signals.down.length})
            </h2>
          </div>

          {signals.down.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-sm" data-testid="no-fallers">
              Sinyal yok
            </div>
          ) : (
            <div className="space-y-2 max-h-[calc(100vh-250px)] overflow-y-auto pr-2">
              {signals.down.map((signal, index) => (
                <div
                  key={`${signal.symbol}-${index}`}
                  className="p-2 rounded hover:bg-[#8b1a1a] transition-colors"
                  style={{ background: '#640b0b', border: '2px solid #8b1a1a' }}
                  data-testid={`faller-${signal.symbol}`}
                >
                  <div className="mb-1">
                    <span className="font-bold text-base" style={{ color: '#FFD700' }}>
                      {signal.symbol}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-white text-xs">{formatPrice(signal.price)}</span>
                    <span className="text-white font-bold text-sm">
                      {signal.change.toFixed(2)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}