import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import CoinList from './CoinList';
import CombinationPanel from './CombinationPanel';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function Dashboard({ onLogout }) {
  const [cryptoData, setCryptoData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTimeframes, setActiveTimeframes] = useState(() => {
    const saved = localStorage.getItem('activeTimeframes');
    return saved ? JSON.parse(saved) : {
      M1: true, M3: true, M5: true, M15: true,
      H1: true, H4: true, H6: true, D1: true,
      '1H': true, '1AY': true
    };
  });

  const fetchData = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API}/crypto/futures`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCryptoData(response.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      if (error.response?.status === 401) {
        onLogout();
      }
    }
  }, [onLogout]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000); // 5 seconds
    return () => clearInterval(interval);
  }, [fetchData]);

  useEffect(() => {
    localStorage.setItem('activeTimeframes', JSON.stringify(activeTimeframes));
  }, [activeTimeframes]);

  const toggleTimeframe = (tf) => {
    setActiveTimeframes(prev => ({ ...prev, [tf]: !prev[tf] }));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a0e27' }}>
        <div className="text-white text-2xl">Yükleniyor...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: '#0a0e27' }} data-testid="dashboard">
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold" style={{ color: '#FFD700' }} data-testid="dashboard-title">
            🎯 CRIMINAL SIGNAL PANEL
          </h1>
          <button
            onClick={onLogout}
            className="px-4 py-2 rounded"
            style={{ background: '#640b0b', color: 'white' }}
            data-testid="logout-button"
          >
            Çıkış
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <CoinList
              data={cryptoData}
              activeTimeframes={activeTimeframes}
              onToggleTimeframe={toggleTimeframe}
            />
          </div>
          <div>
            <CombinationPanel
              data={cryptoData}
              activeTimeframes={activeTimeframes}
            />
          </div>
        </div>
      </div>
    </div>
  );
}