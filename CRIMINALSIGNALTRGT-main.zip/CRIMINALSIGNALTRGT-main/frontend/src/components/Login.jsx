import { useState } from 'react';
import axios from 'axios';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${API}/auth/login`, {
        username,
        password
      });

      localStorage.setItem('token', response.data.access_token);
      onLogin();
    } catch (err) {
      setError('Geçersiz kullanıcı adı veya şifre');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#0a0e27' }}>
      <Card className="w-full max-w-md p-8" style={{ background: '#16224A', border: '1px solid #1a2147' }}>
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold" style={{ color: '#FFD700' }}>🎯 CRIMINAL SIGNAL</h1>
          <p className="text-gray-400 mt-2">Binance Futures Trading Panel</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label className="text-white">Kullanıcı Adı</Label>
            <Input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-2 bg-[#0a0e27] border-[#1a2147] text-white"
              placeholder="TRGT"
              required
              data-testid="login-username"
            />
          </div>

          <div>
            <Label className="text-white">Şifre</Label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-2 bg-[#0a0e27] border-[#1a2147] text-white"
              placeholder="••••••"
              required
              data-testid="login-password"
            />
          </div>

          {error && (
            <div className="text-red-500 text-sm text-center" data-testid="login-error">{error}</div>
          )}

          <Button
            type="submit"
            className="w-full"
            style={{ background: '#FFD700', color: '#0a0e27' }}
            disabled={loading}
            data-testid="login-submit"
          >
            {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
          </Button>
        </form>
      </Card>
    </div>
  );
}