import { useState, useMemo } from 'react';

const TIMEFRAMES = ['M1', 'M3', 'M5', 'M15', 'H1', 'H4', 'H6', 'D1', '1H', '1AY'];

export default function CoinList({ data, activeTimeframes, onToggleTimeframe }) {
  const [sortBy, setSortBy] = useState(() => localStorage.getItem('sortBy') || null);
  const [sortOrder, setSortOrder] = useState(() => localStorage.getItem('sortOrder') || 'asc');

  const TIMEFRAMES = ['M1', 'M3', 'M5', 'M15', 'H1', 'H4', 'H6', 'D1', '1H', '1AY'];

  const handleSort = (column) => {
    if (sortBy === column) {
      if (sortOrder === 'asc') {
        setSortOrder('desc');
        localStorage.setItem('sortOrder', 'desc');
      } else if (sortOrder === 'desc') {
        setSortBy(null);
        setSortOrder('asc');
        localStorage.removeItem('sortBy');
        localStorage.removeItem('sortOrder');
      }
    } else {
      setSortBy(column);
      setSortOrder('asc');
      localStorage.setItem('sortBy', column);
      localStorage.setItem('sortOrder', 'asc');
    }
  };

  const sortedData = useMemo(() => {
    if (!sortBy) return data;

    return [...data].sort((a, b) => {
      let aVal, bVal;

      switch (sortBy) {
        case 'symbol':
          aVal = a.symbol;
          bVal = b.symbol;
          break;
        case 'price':
          aVal = a.price;
          bVal = b.price;
          break;
        case 'volume':
          aVal = a.volume;
          bVal = b.volume;
          break;
        case 'change':
          aVal = a.change_24h;
          bVal = b.change_24h;
          break;
        default:
          return 0;
      }

      if (sortOrder === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });
  }, [data, sortBy, sortOrder]);

  const getSortIcon = (column) => {
    if (sortBy !== column) return '';
    return sortOrder === 'asc' ? ' ▲' : ' ▼';
  };

  const formatVolume = (volume) => {
    if (volume >= 1e9) return `$${(volume / 1e9).toFixed(2)}B`;
    if (volume >= 1e6) return `$${(volume / 1e6).toFixed(2)}M`;
    return `$${volume.toFixed(2)}`;
  };

  const formatPrice = (price) => {
    if (price >= 1000) return price.toFixed(2);
    if (price >= 1) return price.toFixed(4);
    return price.toFixed(6);
  };

  return (
    <div className="rounded-lg overflow-hidden" style={{ background: '#0a0e27', border: '1px solid #1a2147' }} data-testid="coin-list">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr style={{ background: '#0a0e27', borderBottom: '2px solid #1a2147' }}>
              <th
                className="px-4 py-3 text-left cursor-pointer hover:bg-[#2a3459] transition-colors"
                onClick={() => handleSort('symbol')}
                style={{ color: '#FFD700', fontWeight: 'bold' }}
                data-testid="header-symbol"
              >
                Symbol{getSortIcon('symbol')}
              </th>
              <th
                className="px-4 py-3 text-left cursor-pointer hover:bg-[#2a3459] transition-colors"
                onClick={() => handleSort('price')}
                style={{ color: '#FFD700', fontWeight: 'bold' }}
                data-testid="header-price"
              >
                $ Fiyat{getSortIcon('price')}
              </th>
              <th
                className="px-4 py-3 text-left cursor-pointer hover:bg-[#2a3459] transition-colors"
                onClick={() => handleSort('volume')}
                style={{ color: '#FFD700', fontWeight: 'bold' }}
                data-testid="header-volume"
              >
                Hacim{getSortIcon('volume')}
              </th>
              <th
                className="px-4 py-3 text-left cursor-pointer hover:bg-[#2a3459] transition-colors"
                onClick={() => handleSort('change')}
                style={{ color: '#FFD700', fontWeight: 'bold' }}
                data-testid="header-change"
              >
                24H %{getSortIcon('change')}
              </th>
              {TIMEFRAMES.map(tf => (
                <th
                  key={tf}
                  className="px-2 py-2 text-center cursor-pointer hover:bg-[#1a2970] transition-colors"
                  onClick={() => onToggleTimeframe(tf)}
                  style={{
                    background: '#16224A',
                    minWidth: '42px'
                  }}
                  data-testid={`header-${tf}`}
                >
                  <button
                    className="px-2 py-1 rounded text-xs font-bold text-white transition-all w-full"
                    style={{ 
                      background: activeTimeframes[tf] ? '#084808' : '#333',
                      opacity: activeTimeframes[tf] ? 1 : 0.5,
                      cursor: 'pointer'
                    }}
                  >
                    {tf}
                  </button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedData.map((coin, index) => (
              <tr
                key={coin.symbol}
                className="hover:bg-[#0f1433] transition-colors"
                style={{ borderBottom: '1px solid #1a2147', background: '#0a0e27' }}
                data-testid={`coin-row-${coin.symbol}`}
              >
                <td className="px-4 py-2 text-sm" style={{ color: '#FFD700', fontWeight: 'bold' }} data-testid={`coin-symbol-${coin.symbol}`}>
                  {coin.symbol}
                </td>
                <td className="px-4 py-2 text-white text-sm" data-testid={`coin-price-${coin.symbol}`}>
                  {formatPrice(coin.price)}
                </td>
                <td className="px-4 py-2 text-white text-sm" data-testid={`coin-volume-${coin.symbol}`}>
                  {formatVolume(coin.volume)}
                </td>
                <td
                  className="px-4 py-2 font-bold text-sm"
                  style={{ color: coin.change_24h >= 0 ? '#084808' : '#640b0b' }}
                  data-testid={`coin-change-${coin.symbol}`}
                >
                  {coin.change_24h >= 0 ? '+' : ''}{coin.change_24h.toFixed(2)}%
                </td>
                {TIMEFRAMES.map(tf => {
                  const signal = coin.signals[tf];
                  const isActive = activeTimeframes[tf];
                  
                  return (
                    <td key={tf} className="px-2 py-2 text-center" style={{ background: '#0a0e27' }} data-testid={`coin-signal-${coin.symbol}-${tf}`}>
                      {isActive ? (
                        <span
                          className="inline-block w-3 h-3 rounded-full"
                          style={{
                            background: signal === 'up' ? '#084808' : signal === 'down' ? '#640b0b' : '#666'
                          }}
                        />
                      ) : (
                        <span
                          className="inline-block w-3 h-3 rounded-full border-2"
                          style={{ borderColor: '#666', background: 'transparent' }}
                        />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}