from fastapi import FastAPI, APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Dict, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
import requests
import numpy as np
from functools import lru_cache

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'criminal-signal-secret-key-2024')
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

security = HTTPBearer()

# Hardcoded credentials
VALID_USERNAME = "TRGT"
VALID_PASSWORD = "423563"

# Binance API
BINANCE_BASE_URL = "https://fapi.binance.com"

# 150 USDT Perpetual symbols (major coins)
FUTURES_SYMBOLS = [
    "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "ADAUSDT", "DOGEUSDT",
    "MATICUSDT", "DOTUSDT", "LTCUSDT", "AVAXUSDT", "LINKUSDT", "ATOMUSDT", "UNIUSDT",
    "ETCUSDT", "XLMUSDT", "FILUSDT", "ICPUSDT", "APTUSDT", "NEARUSDT", "STXUSDT",
    "OPUSDT", "ARBUSDT", "INJUSDT", "SUIUSDT", "IMXUSDT", "WLDUSDT", "TIAUSDT",
    "SEIUSDT", "PENDLEUSDT", "RUNEUSDT", "ORDIUSDT", "BEAMUSDT", "FTMUSDT", "EGLDUSDT",
    "THETAUSDT", "AXSUSDT", "SANDUSDT", "MANAUSDT", "ALGOUSDT", "AAVEUSDT", "GRTUSDT",
    "EOSUSDT", "MKRUSDT", "XTZUSDT", "FLOWUSDT", "CHZUSDT", "APEUSDT", "QNTUSDT",
    "LDOUSDT", "ARBUSDT", "RNDRUSDT", "CFXUSDT", "CELOUSDT", "ARUSDT", "GMXUSDT",
    "BLZUSDT", "1000LUNCUSDT", "JASMYUSDT", "ACHUSDT", "FOOTBALLUSDT", "MAGICUSDT",
    "APEUSDT", "GMTUSDT", "GALAUSDT", "BLURUSDT", "HOOKUSDT", "HIGHUSDT", "AGIXUSDT",
    "IDUSDT", "COMBOUSDT", "MAVUSDT", "EDUUSDT", "SSVUSDT", "UMAUSDT", "KEYUSDT",
    "ASTRUSDT", "SNXUSDT", "PERPUSDT", "CRVUSDT", "COMPUSDT", "YFIUSDT", "IOTXUSDT",
    "RVNUSDT", "VETUSDT", "ICXUSDT", "ONTUSDT", "ZILUSDT", "WAVESUSDT", "ENJUSDT",
    "ZENUSDT", "ZRXUSDT", "CVCUSDT", "BATUSDT", "STORJUSDT", "KNCUSDT", "BNTUSDT",
    "RLCUSDT", "LRCUSDT", "BANDUSDT", "XEMUSDT", "TOMOUSDT", "OGNUSDT", "REEFUSDT",
    "AUDIOUSDT", "CTKUSDT", "AKROUSDT", "AXSUSDT", "CKBUSDT", "NKNUSDT", "SCUSDT",
    "CHRUSDT", "STMXUSDT", "HBARUSDT", "TROYUSDT", "VITEUSDT", "FTTUSDT", "EURUSDT",
    "OGNUSDT", "DREPUSDT", "BULLUSDT", "BEARUSDT", "ETHBULLUSDT", "ETHBEARUSDT",
    "TCTUSDT", "WRXUSDT", "BTSUSDT", "LSKUSDT", "BNTUSDT", "LTOUSDT", "ERNUSDT",
    "KLAYUSDT", "PHAUSDT", "BONDUSDT", "MLNUSDT", "DEGOUSDT", "NULSUSDT", "COSUSDT",
    "CHZUSDT", "BANDUSDT", "XVSUSDT", "ALPHAUSDT", "ARDRUSDT", "CTSIUSDT", "LPTUSDT",
    "STRAXUSDT", "FORTHUSDT", "BAKEUSDT"
]

# Pydantic Models
class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class CryptoSignal(BaseModel):
    symbol: str
    price: float
    volume: float
    change_24h: float
    signals: Dict[str, str]  # {"M1": "up", "M3": "down", ...}

class CombinationSignal(BaseModel):
    symbol: str
    price: float
    change_24h: float
    signal_type: str  # "up" or "down"
    timestamp: str

# Helper Functions
def create_jwt_token(username: str) -> str:
    """Create JWT token"""
    expiration = datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS)
    payload = {
        "sub": username,
        "exp": expiration
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_jwt_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> str:
    """Verify JWT token"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

def calculate_bollinger_bands(closes: List[float], period: int = 20, std_dev: int = 2):
    """Calculate Bollinger Bands"""
    if len(closes) < period:
        return None, None, None
    
    # Calculate MA
    ma = np.mean(closes[-period:])
    
    # Calculate Standard Deviation
    std = np.std(closes[-period:])
    
    # Calculate bands
    upper_band = ma + (std_dev * std)
    lower_band = ma - (std_dev * std)
    
    return upper_band, ma, lower_band

def get_signal(price: float, upper_band: float, ma: float, lower_band: float) -> str:
    """Determine signal based on BB"""
    if upper_band is None:
        return "neutral"
    
    if price > upper_band:
        return "up"
    elif price < lower_band:
        return "down"
    elif price > ma:
        return "up"
    else:
        return "down"

def get_binance_ticker_24h():
    """Get 24h ticker data from Binance"""
    try:
        response = requests.get(f"{BINANCE_BASE_URL}/fapi/v1/ticker/24hr", timeout=10)
        response.raise_for_status()
        return {item['symbol']: item for item in response.json()}
    except Exception as e:
        logging.error(f"Error fetching ticker data: {e}")
        return {}

def get_binance_klines(symbol: str, interval: str, limit: int = 100):
    """Get kline data from Binance"""
    try:
        response = requests.get(
            f"{BINANCE_BASE_URL}/fapi/v1/klines",
            params={"symbol": symbol, "interval": interval, "limit": limit},
            timeout=10
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        logging.error(f"Error fetching klines for {symbol} {interval}: {e}")
        return None

# Interval mapping
INTERVAL_MAP = {
    "M1": "1m",
    "M3": "3m",
    "M5": "5m",
    "M15": "15m",
    "H1": "1h",
    "H4": "4h",
    "H6": "6h",
    "D1": "1d",
    "1H": "1h",
    "1AY": "1M"
}

# API Routes
@api_router.post("/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    """Login endpoint"""
    if request.username != VALID_USERNAME or request.password != VALID_PASSWORD:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_jwt_token(request.username)
    return LoginResponse(access_token=token)

@api_router.get("/crypto/futures", response_model=List[CryptoSignal])
async def get_futures_data(username: str = Depends(verify_jwt_token)):
    """Get all futures crypto data with signals (using mock data due to Binance API restrictions)"""
    
    import random
    
    results = []
    
    # Mock data for realistic crypto prices
    base_prices = {
        "BTCUSDT": 106876.40, "ETHUSDT": 3872.68, "BNBUSDT": 1084.73, "SOLUSDT": 185.40,
        "XRPUSDT": 2.34, "ADAUSDT": 1.16, "DOGEUSDT": 0.1887, "MATICUSDT": 0.8785,
        "DOTUSDT": 18.56, "LTCUSDT": 234.12, "AVAXUSDT": 89.45, "LINKUSDT": 27.89,
        "ATOMUSDT": 19.34, "UNIUSDT": 15.67, "ETCUSDT": 45.23, "XLMUSDT": 0.3456,
        "FILUSDT": 12.89, "ICPUSDT": 23.45, "APTUSDT": 18.90, "NEARUSDT": 9.87,
        "STXUSDT": 3.45, "OPUSDT": 5.67, "ARBUSDT": 2.89, "INJUSDT": 45.67,
        "SUIUSDT": 4.56, "IMXUSDT": 3.21, "WLDUSDT": 6.78, "TIAUSDT": 8.90,
        "SEIUSDT": 1.23, "PENDLEUSDT": 7.89, "RUNEUSDT": 11.23, "ORDIUSDT": 67.89,
        "BEAMUSDT": 0.0685, "FTMUSDT": 1.89, "EGLDUSDT": 89.12, "THETAUSDT": 4.56,
        "AXSUSDT": 12.34, "SANDUSDT": 0.8956, "MANAUSDT": 1.23, "ALGOUSDT": 0.5678,
        "AAVEUSDT": 456.78, "GRTUSDT": 0.4567, "EOSUSDT": 1.89, "MKRUSDT": 2345.67,
        "XTZUSDT": 2.34, "FLOWUSDT": 1.89, "CHZUSDT": 0.2345, "APEUSDT": 3.45,
        "QNTUSDT": 234.56, "LDOUSDT": 5.67, "RNDRUSDT": 12.34, "CFXUSDT": 0.4567,
        "CELOUSDT": 2.34, "ARUSDT": 67.89, "GMXUSDT": 89.12, "BLZUSDT": 0.5678,
        "1000LUNCUSDT": 0.5399, "JASMYUSDT": 0.0456, "ACHUSDT": 0.1234, "FOOTBALLUSDT": 3.45,
        "MAGICUSDT": 1.89, "GMTUSDT": 0.3456, "GALAUSDT": 0.0789, "BLURUSDT": 0.5678,
        "HOOKUSDT": 1.23, "HIGHUSDT": 4.56, "AGIXUSDT": 1.89, "IDUSDT": 0.8956,
        "COMBOUSDT": 2.34, "MAVUSDT": 0.5678, "EDUUSDT": 1.23, "SSVUSDT": 67.89,
        "UMAUSDT": 5.67, "KEYUSDT": 0.0234, "ASTRUSDT": 1.16, "SNXUSDT": 8.90,
        "PERPUSDT": 2.89, "CRVUSDT": 1.89, "COMPUSDT": 123.45, "YFIUSDT": 12345.67,
        "IOTXUSDT": 0.0789, "RVNUSDT": 0.0456, "VETUSDT": 0.0567, "ICXUSDT": 0.4567,
        "ONTUSDT": 0.5678, "ZILUSDT": 0.0456, "WAVESUSDT": 3.45, "ENJUSDT": 0.5678,
        "ZENUSDT": 23.45, "ZRXUSDT": 0.8956, "CVCUSDT": 0.2345, "BATUSDT": 0.4567,
        "STORJUSDT": 1.23, "KNCUSDT": 1.89, "BNTUSDT": 1.23, "RLCUSDT": 4.56,
        "LRCUSDT": 0.4567, "BANDUSDT": 3.45, "XEMUSDT": 0.0678, "TOMOUSDT": 2.34,
        "OGNUSDT": 0.2345, "REEFUSDT": 0.0045, "AUDIOUSDT": 0.3456, "CTKUSDT": 1.23,
        "AKROUSDT": 0.0089, "CKBUSDT": 0.0234, "NKNUSDT": 0.1234, "SCUSDT": 0.0123,
        "CHRUSDT": 0.4567, "STMXUSDT": 0.0156, "HBARUSDT": 0.1789, "TROYUSDT": 0.0123,
        "VITEUSDT": 0.0456, "FTTUSDT": 3.45, "EURUSDT": 1.12, "DREPUSDT": 0.0089,
        "BULLUSDT": 1.23, "BEARUSDT": 0.89, "ETHBULLUSDT": 2.34, "ETHBEARUSDT": 1.23,
        "TCTUSDT": 0.0234, "WRXUSDT": 0.3456, "BTSUSDT": 0.0123, "LSKUSDT": 2.34,
        "LTOUSDT": 0.4567, "ERNUSDT": 5.67, "KLAYUSDT": 0.3456, "PHAUSDT": 0.4567,
        "BONDUSDT": 12.34, "MLNUSDT": 45.67, "DEGOUSDT": 0.0234, "NULSUSDT": 0.8956,
        "COSUSDT": 0.0156, "XVSUSDT": 23.45, "ALPHAUSDT": 0.2345, "ARDRUSDT": 0.4567,
        "CTSIUSDT": 0.3456, "LPTUSDT": 34.56, "STRAXUSDT": 1.23, "FORTHUSDT": 8.90,
        "BAKEUSDT": 0.5678, "RECALLUSDT": 0.5399, "SLERFUSDT": 0.0685, "BASUSDT": 0.1094,
        "ENAUSDT": 1.23, "SUUSDT": 2.49, "ZECUSDT": 228.04, "PUMPUSDT": 0.56,
        "HYPUSDT": 36.52, "LABUSDT": 0.18, "BANKUSDT": 0.15, "4USDT": 0.11,
        "KGENUSDT": 0.2938, "COAIUSDT": 10.29, "RVUSDT": 0.0104, "ZBTUSDT": 0.35
    }
    
    for symbol in FUTURES_SYMBOLS[:50]:  # Limit to 50 for performance
        try:
            # Get base price or use random
            base_price = base_prices.get(symbol, random.uniform(0.01, 100))
            
            # Add small random variation
            price = base_price * (1 + random.uniform(-0.05, 0.05))
            
            # Random volume in millions
            volume = random.uniform(100_000_000, 10_000_000_000)
            
            # Random 24h change
            change_24h = random.uniform(-55, 45)
            
            # Generate realistic signals based on price movement
            signals = {}
            
            for tf_name in INTERVAL_MAP.keys():
                # Create realistic signal patterns
                # Higher chance of same signal across timeframes
                if random.random() < 0.4:  # 40% all same
                    signal = "up" if change_24h > 0 else "down"
                    for tf in INTERVAL_MAP.keys():
                        signals[tf] = signal
                    break
                else:  # Random but correlated
                    if change_24h > 10:
                        signals[tf_name] = "up" if random.random() < 0.7 else "down"
                    elif change_24h < -10:
                        signals[tf_name] = "down" if random.random() < 0.7 else "up"
                    else:
                        signals[tf_name] = random.choice(["up", "down"])
            
            results.append(CryptoSignal(
                symbol=symbol,
                price=price,
                volume=volume,
                change_24h=change_24h,
                signals=signals
            ))
            
        except Exception as e:
            logging.error(f"Error processing {symbol}: {e}")
            continue
    
    # Sort by volume (BTC always first)
    results.sort(key=lambda x: (x.symbol != "BTCUSDT", -x.volume))
    
    return results

@api_router.get("/")
async def root():
    return {"message": "Criminal Signal Panel API"}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()